import numpy as np
import scipy.io as sio
from torch.utils.data import Dataset, DataLoader
import torch
import random


def load_data(datasets, align_prop):
    all_data = []
    label = []

    mat = sio.loadmat('./datasets/' + datasets + '.mat')
    if datasets == 'Scene15':
        data = mat['X'][0][0:2]  # 20, 59 dimensions
        label = np.squeeze(mat['Y'])

    elif datasets == 'Caltech101-20':
        data = mat['X'][0][3:5]
        label = np.squeeze(mat['Y'])

    elif datasets == 'NoisyMNIST':
        data = []
        data.append(mat['X1'])
        data.append(mat['X2'])
        label = np.squeeze(mat['Y'])

    divide_seed = random.randint(1, 1000)
    train_idx, test_idx = (len(label), 1 - align_prop, divide_seed)
    train_label, test_label = label[train_idx], label[test_idx]
    train_X, train_Y, test_X, test_Y = data[0][train_idx], data[1][train_idx], data[0][test_idx], data[1][test_idx]

    # Use test_prop*sizeof(all data) to train, and shuffle the rest data to simulate the unaligned data.
    # When test_prop = 0, MvC is directly performed on the all data without shuffling.
    if align_prop == 1.:
        all_data.append(train_X.T)
        all_data.append(train_Y.T)
        all_label, all_label_X, all_label_Y = train_label, train_label, train_label
    else:
        shuffle_idx = random.sample(range(len(test_Y)), len(test_Y))
        test_Y = test_Y[shuffle_idx]
        test_label_X, test_label_Y = test_label, test_label[shuffle_idx]
        all_data.append(np.concatenate((train_X, test_X)).T)
        all_data.append(np.concatenate((train_Y, test_Y)).T)
        all_label = np.concatenate((train_label, test_label))
        all_label_X = np.concatenate((train_label, test_label_X))
        all_label_Y = np.concatenate((train_label, test_label_Y))

    return all_data, all_label, all_label_X, all_label_Y, divide_seed

class GetDataset(Dataset):
    def __init__(self, data, labels, real_labels):
        self.data = data
        self.labels = labels
        self.real_labels = real_labels

    def __getitem__(self, index):
        fea0, fea1 = torch.from_numpy(self.data[0][:, index]).float(), torch.from_numpy(self.data[1][:, index]).float()
        fea0, fea1 = fea0.unsqueeze(0), fea1.unsqueeze(0)
        label = np.int64(self.labels[index])
        if len(self.real_labels) == 0:
            return fea0, fea1, label
        real_label = np.int64(self.real_labels[index])
        return fea0, fea1, label, real_label

    def __len__(self):
        return len(self.labels)


class GetAllDataset(Dataset):
    def __init__(self, data, labels, class_labels0, class_labels1):
        self.data = data
        self.labels = labels
        self.class_labels0 = class_labels0
        self.class_labels1 = class_labels1

    def __getitem__(self, index):
        fea0, fea1 = torch.from_numpy(self.data[0][:, index]).float(), torch.from_numpy(self.data[1][:, index]).float()
        fea0, fea1 = fea0.unsqueeze(0), fea1.unsqueeze(0)
        label = np.int64(self.labels[index])
        class_labels0 = np.int64(self.class_labels0[index])
        class_labels1 = np.int64(self.class_labels1[index])
        return fea0, fea1, label, class_labels0, class_labels1

    def __len__(self):
        return len(self.labels)


def loader(aligned_prop, dataset):
    train_pairs, train_pair_labels, train_pair_real_labels, all_data, all_label, all_label_X, all_label_Y, \
    divide_seed = load_data(dataset,aligned_prop)
    all_dataset = GetAllDataset(all_data, all_label, all_label_X, all_label_Y)


    all_loader = DataLoader(
        all_dataset,
        batch_size=1024,
        shuffle=True
    )
    return all_loader, divide_seed
